define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){
  var mytablecollection = Backbone.Collection.extend({
		/* byLob: function (lob) {
        filtered = this.filter(function (model) {
            return model.get("lob") === lob;
        });
        return new mybenchcollection(filtered);
    }
 */
  });
 
  return mytablecollection;
});
