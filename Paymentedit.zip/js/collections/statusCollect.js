define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){
  var statusCollect = Backbone.Collection.extend({
   
    
    url : "testdata/sample/sample.json",
	
		parse : function(response){
			 console.log(response);
			  return response;
			 
		  }

  });
 
  return statusCollect;
});
