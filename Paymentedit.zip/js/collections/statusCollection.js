define([
  'underscore',
  'backbone',
  'models/statusModel'
 ], function(_, Backbone,modeldata) {
	 
	 var CollectionData = Backbone.Collection.extend({
		 model:modeldata
	 });
	 return CollectionData;
 });
	