define([
  'jquery',
  'underscore',
  'backbone',
  'views/status/StatusView',
  'models/statusModel',
  'collections/statusCollect',
  'views/table/tableView',
  'models/tabledataModel',
  'views/table/statusTableView',
  'views/transaction/TransactionView',
  'collections/tablecollection/tableCollection'
],
function($,_,Backbone,StatusView,ModelObj,statusCollect,tableView,tabledataModel,statusTableView,TransactionView,tableCollection){
	
	var routerTeamProject = Backbone.Router.extend({

	routes: {
		//
		//'','homefn',
		'table/:work':'tablefn',
		'transaction':'transactionfn',
	   'status/:stat':'statusfn',
          'status': 'statusFunction'
         
		}
	});
	
	//Fetching sample.json
	var Collobject= new statusCollect();
	Collobject.fetch();
	console.log("Fetching sample.json");
	console.log(Collobject);
	
	var mydata;
	
	
	var tabledataModelObj= new tableCollection();
	tabledataModelObj.fetch();
	tabledataModelObj.fetch({context:tabledataModelObj}).done(function() {
						console.log(this.length);
						this.count = this.length;
						console.log(tabledataModelObj);
	 })
	
	var statusTablecollobj=new tableCollection();
	 console.log("obj created");
	statusTablecollobj.fetch({context:statusTablecollobj}).done(function() {
						console.log(this.length);
						this.count = this.length;
						console.log(statusTablecollobj);
	 });
	
	
	
	var initialize=function(){
		var routeobj = new routerTeamProject();
		
		routeobj.on('route:statusFunction',function () {
				var statusView = new StatusView({Collobject1: Collobject}); 
					statusView.render();
			
					
		});
		
			routeobj.on('route:tablefn',function (work) {
			console.log("inside router");
				var tableViewobj = new tableView({tabledataModelObj1: tabledataModelObj,
				work1:work
				}); 
		});
		
		
		
		
		routeobj.on('route:transactionfn',function () {
			console.log("inside transactionrouter");
				var TransactionViewobj = new TransactionView({Collobject1: Collobject}); 
				console.log("inside transactionrouter object");
		});
		
		 routeobj.on('route:statusfn',function (stat) {
			console.log("inside router");
				var statusTableViewobj = new statusTableView(
				{
					statusTablecollobj: statusTablecollobj,
					stat1: stat
				}); 
		});
	
	Backbone.history.start();
	};
	return{
		initialize:initialize
	};	
	
});
	
