define(['jquery','underscore','backbone','handlebar','router'],
function($,_,Backbone,Handlebars,Router){
	var initialize = function(){
		console.log("Inside App");
		Router.initialize();
	};
	return{
		initialize:initialize
	};
});