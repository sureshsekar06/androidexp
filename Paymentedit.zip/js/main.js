require.config({
	paths:{
		bootstrap:'libs/bootstrap/js/bootstrap.min',
		jquery:'libs/jquery/jquery-min',
		underscore:'libs/underscore/underscore-min',
		backbone:'libs/backbone/backbone-min',
		highcharts:'libs/highcharts/highcharts',
		highchart:'libs/highcharts/exporting',
		//data:'libs/highcharts/data',
		//drilldown:'libs/highcharts/drilldown',
		highchart3d:'libs/highcharts/highcharts-3d',
		handlebar:'libs/handlebars/handlebars-v4.0.5',
		templates:'../templates'
	}
});

require(['app'],function(App){
	console.log("inside main");
	App.initialize();
});