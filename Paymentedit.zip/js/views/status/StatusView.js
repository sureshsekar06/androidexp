define(['jquery','underscore','backbone','handlebar','collections/statusCollection','highcharts','highchart','text!templates/status/status.tpl'],
		function($,_,Backbone,Handlebars,CollectionData,Highcharts,Highchart,Statustpl){
			
			var myname;
			
			var StatusView = Backbone.View.extend({
				
				initialize:function(options){
					this.Collobject2=options.Collobject1;
					
					console.log("heloooo");
					console.log(this.Collobject2);
					this.Collobject3=this.Collobject2.models;
					//console.log(this.Collobject3[0].attributes.data);
					statusN = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "N")
							statusN += 1;
					}
					console.log(statusN);
					
					statusA = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "A")
							statusA += 1;
					}
					console.log(statusA);
					
					
					statusI = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "I")
							statusI += 1;
					}
					console.log(statusI);
					
					statusS = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "S")
							statusS += 1;
					}
					console.log(statusS);
					
					statusR = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "R")
							statusR += 1;
					}
					console.log(statusR);
					
					statusC = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "C")
							statusC += 1;
					}
					console.log(statusC);
					
					statusP = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "P")
							statusP += 1;
					}
					console.log(statusP);
					
					statusB = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "B")
							statusB += 1;
					}
					console.log(statusB);
					
					statusL = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "L")
							statusL += 1;
					}
					console.log(statusL);
					
					statusM = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(this.Collobject3[0].attributes.data[i].status === "M")
							statusM += 1;
					}
					console.log(statusM);
					
					this.statusN = statusN;
					this.statusA = statusA;
					this.statusI = statusI;
					this.statusS = statusS;
					this.statusR = statusR;
					this.statusC = statusC;
					this.statusP = statusP;
					this.statusB = statusB;
					this.statusL = statusL;
					this.statusM = statusM;
					
					// For Transaction table
					
					statusNP = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "Payment"))
							statusNP += 1;
					}
					console.log(statusNP);
					
					statusNPE = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "PaymentEligible"))
							statusNPE += 1;
					}
					console.log(statusNPE);
					
					statusNPN = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "PaymentNotEligible"))
							statusNPN += 1;
					}
					console.log(statusNPN);
					
					statusAIS = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(((this.Collobject3[0].attributes.data[i].status === "A")||(this.Collobject3[0].attributes.data[i].status === "I")||(this.Collobject3[0].attributes.data[i].status === "S"))&&(this.Collobject3[0].attributes.data[i].transactionType === "Payment"))
							statusAIS += 1;
					}
					console.log(statusAIS);
					
					
					statusNCE = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "CancelEligible"))
							statusNCE += 1;
					}
					console.log(statusNCE);
					
					statusNCN = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "CancelNotEligible"))
							statusNCN += 1;
					}
					console.log(statusNCN);
					
					this.statusNP = statusNP;
					this.statusNPE = statusNPE;
					this.statusNPN = statusNPN;
					this.statusAIS = statusAIS;
					this.statusNCE = statusNCE;
					this.statusNCN = statusNCN;
					
					
				},
				el:$('#posthere'),
				template:Handlebars.compile(Statustpl),
				render:function(){
					this.$el.html(this.template({
						statusN:this.statusN,
						statusA:this.statusA,
						statusI:this.statusI,
						statusS:this.statusS,
						statusR:this.statusR,
						statusC:this.statusC,
						statusP:this.statusP,
						statusB:this.statusB,
						statusL:this.statusL,
						statusM:this.statusM,
						// Transaction
						statusNP:this.statusNP,
						statusNPE:this.statusNPE,
						statusNPN:this.statusNPN,
						statusAIS:this.statusAIS,
						statusNCE:this.statusNCE,
						statusNCN:this.statusNCN
						
					}));                       
				}                              
			           
					   
			});                                
	return StatusView;
}); 

