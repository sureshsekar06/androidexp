console.log("inside view");
define(['jquery','underscore','backbone','handlebar','text!templates/table.tpl','collections/tablecollection/mytablecollection','collections/tablecollection/tableCollection'],
		function($,_,Backbone,Handlebars,table,mytablecollection,tableCollection){
			//registering if helper
			Handlebars.registerHelper('ifCond', function(v1, v2, option) {
			  if(v1 === v2) {
				return option.fn(this);
			  }
			  return option.inverse(this);
			});
			
			
			
		
			
			var tableView = Backbone.View.extend({
				
				initialize:function(option){
					
				
					
					this.statuscollobj=option.tabledataModelObj1;					
						console.log(this.statuscollobj);
						
						console.log(this.statuscollobj.models[0].attributes.data.length);
						console.log(this.statuscollobj.models);
						
						
						// this.statuscollobjmodels=this.statuscollobj.models;
						// console.log(this.statuscollobjmodels.length);
						
						 var mytablecollobj=new mytablecollection();
						// mytablecollobj.add(this.statuscollobjmodels);
						// console.log(mytablecollobj.models[0].attributes.data[0].paymentId);
						// console.log(mytablecollobj.models[0].attributes.data.length);
						
						
						//console.log(mytablecollobj.where({status:"N"}));
						console.log(option.work1);
						
						
						if(option.work1==="edit")
						{
							for(i=0;i<this.statuscollobj.models[0].attributes.data.length;i++)
							{
								if((this.statuscollobj.models[0].attributes.data[i].status=="N")&&(this.statuscollobj.models[0].attributes.data[i].transactionType === "Payment"))
								{
									this.tableviewdata=mytablecollobj.add(this.statuscollobj.models[0].attributes.data[i]);
									console.log(this.tableviewdata);
								}
							}
							
						}
						
						console.log(this.tableviewdata);
						if(option.work1==="app_rej_eligible")
						{
							for(i=0;i<this.statuscollobj.models[0].attributes.data.length;i++)
							{
								if((this.statuscollobj.models[0].attributes.data[i].status=="N")&&(this.statuscollobj.models[0].attributes.data[i].transactionType === "PaymentEligible"))
								{
									this.tableviewdata=mytablecollobj.add(this.statuscollobj.models[0].attributes.data[i]);
									console.log(mytablecollobj);
								}
							}
							
						}
						if(option.work1==="app_rej_noteligible")
						{
							for(i=0;i<this.statuscollobj.models[0].attributes.data.length;i++)
							{
								if((this.statuscollobj.models[0].attributes.data[i].status=="N")&&(this.statuscollobj.models[0].attributes.data[i].transactionType === "PaymentNotEligible"))
								
								{
									this.tableviewdata=mytablecollobj.add(this.statuscollobj.models[0].attributes.data[i]);
									console.log(mytablecollobj);
								}
							}
							
						}
						if(option.work1==="cancel")
						{
							for(i=0;i<this.statuscollobj.models[0].attributes.data.length;i++)
							{
								if((this.statuscollobj.models[0].attributes.data[i].status=="A")||(this.statuscollobj.models[0].attributes.data[i].status === "I")||(this.statuscollobj.models[0].attributes.data[i].status === "S")&&(this.statuscollobj.models[0].attributes.data[i].transactionType === "Payment"))
								{
									this.tableviewdata=mytablecollobj.add(this.statuscollobj.models[0].attributes.data[i]);
									console.log(mytablecollobj);
								}
							}
							
						}if(option.work1==="cancel_app_rej_eligible")
						{
							for(i=0;i<this.statuscollobj.models[0].attributes.data.length;i++)
							{
								if((this.statuscollobj.models[0].attributes.data[i].status=="N")&&(this.statuscollobj.models[0].attributes.data[i].transactionType === "CancelEligible"))
								{
									this.tableviewdata=mytablecollobj.add(this.statuscollobj.models[0].attributes.data[i]);
									console.log(mytablecollobj);
								}
							}
							
						}
						if(option.work1==="cancel_app_rej_noteligible")
						{
							for(i=0;i<this.statuscollobj.models[0].attributes.data.length;i++)
							{
								if((this.statuscollobj.models[0].attributes.data[i].status=="N")&&(this.statuscollobj.models[0].attributes.data[i].transactionType === "CancelNotEligible"))
								{
									this.tableviewdata=mytablecollobj.add(this.statuscollobj.models[0].attributes.data[i]);
									console.log(mytablecollobj);
								}
							}
							
						}
						
							
					

					
					if(option.work1==="edit")
						this.title = "Edit";
					else if(option.work1==="app_rej_eligible")
						this.title = "Approve/Reject Eligible";
					else if(option.work1==="app_rej_noteligible")
						this.title = "Approve/Reject not Eligible";
					
					else if(option.work1==="cancel")
						this.title = "Cancel";
					else if(option.work1==="cancel_app_rej_eligible")
						this.title = "Cancel Approve/Reject Eligible";
					else if(option.work1==="cancel_app_rej_noteligible")
						this.title = "Cancel Approve/Reject not Eligible";
					
					
						console.log(this.tableviewdata.models[0].attributes.paymentId);
						this.editString = "<a href=\"#\" class=\"edit-blog\" id=\"edit{{@index}}\" data-editbar =\"{{@index}}\"><span class=\"glyphicon glyphicon-pencil fa-1x\"></span></a><a href=\"#\" class=\"update-blog\" id=\"update{{@index}}\" data-updatebar =\"{{@index}}\" style=\"display:none\"><span class=\"glyphicon glyphicon-arrow-up fa-1x\"></a><a href=\"#\" class=\"cancel-blog\" id=\"cancel{{@index}}\" data-cancelbar =\"{{@index}}\" style=\"display:none\"><span class=\"glyphicon glyphicon-remove fa-1x\"></a>";
						this.approveString = "<a href=\"#\"><span class=\"glyphicon glyphicon-ok\"></span></a><a href=\"#\"><span class=\"glyphicon glyphicon-remove\"></span></a>";
						this.optionswork = option.work1;
						this.render();
						
					},
					
					events: {
							
							
							'click .edit-blog ': 'edit',
							'click .update-blog': 'update',
							 'click .cancel-blog': 'cancel'
								// 'click .delete-blog': 'delete'
							},
							edit: function(eve) {
								var editbar = $(eve.currentTarget).data('editbar');
								var string1 = new Array();
								
								string1[0] = "edit"+editbar;
								string1[1] = "update"+editbar;
								string1[2] = "cancel"+editbar;
								string1[3] = "paymentId"+editbar;
								string1[4] = "paymentType"+editbar;
								string1[5] = "transactionType"+editbar;
								string1[6] = "currency"+editbar;
								string1[7] = "beneficiaryBank"+editbar;
								string1[8] = "directionLabel"+editbar;
								string1[9] = "conceptPayment"+editbar;
								string1[10] = "referenceNumber"+editbar;
								string1[11] = "typeOfOperation"+editbar;
								string1[12] = "transactionAmount"+editbar;
								string1[13] = "originatorDownstream"+editbar;
								string1[14] = "targetUpstream"+editbar;
								string1[15] = "topologyType"+editbar;
								string1[16] = "transactionDate"+editbar;
								string1[17] = "priority"+editbar;
								
								
								
								
								
								console.log(string1[0]);
								this.$('#'+string1[0]).hide();
								//$('.delete-blog').hide();
								
								this.$('#'+string1[1]).show();
								this.$('#'+string1[2]).show();
								
								var directionLabel =$('#'+string1[8]).html() ;
								var conceptPayment =$('#'+string1[9]).html() ;
								var referenceNumber =$('#'+string1[10]).html () ;
								var typeOfOperation =$('#'+string1[11]).html() ;
								var transactionAmount =$('#'+string1[12]).html() ;
								
								var originatorDownstream =$('#'+string1[13]).html() ;
								var targetUpstream =$('#'+string1[14]).html() ;
								var topologyType =$('#'+string1[15]).html () ;
								var transactionDate =$('#'+string1[16]).html() ;
								var priority =$('#'+string1[17]).html() ;
								
								
								
								
								
								
								console.log(string1[9]);
								//var age = this.$('.age').html();
								//var number = this.$('.number').html();

								this.$('#'+string1[8]).html('<input type="text" class="form-control directionLabel" id="directionLabel" value="' + directionLabel  + '">');
								this.$('#'+string1[9]).html('<input type="text" class="form-control conceptPayment" id="conceptPayment" value="' + conceptPayment + '">');
								this.$('#'+string1[10]).html('<input type="text" class="form-control referenceNumber" id="referenceNumber" value="' + referenceNumber + '">');
								this.$('#'+string1[11]).html('<input type="text" class="form-control typeOfOperation" id="typeOfOperation" value="' + typeOfOperation + '">');
								this.$('#'+string1[12]).html('<input type="text" class="form-control transactionAmount" id="transactionAmount" value="' + transactionAmount + '">');
								
								this.$('#'+string1[13]).html('<input type="text" class="form-control originatorDownstream" id="originatorDownstream" value="' + originatorDownstream  + '">');
								this.$('#'+string1[14]).html('<input type="text" class="form-control targetUpstream" id="targetUpstream" value="' + targetUpstream + '">');
								this.$('#'+string1[15]).html('<input type="text" class="form-control topologyType" id="topologyType" value="' + topologyType + '">');
								this.$('#'+string1[16]).html('<input type="text" class="form-control transactionDate" id="transactionDate" value="' + transactionDate + '">');
								this.$('#'+string1[17]).html('<input type="text" class="form-control priority" id="priority" value="' + priority + '">');
								
								
								//this.$('.age').html('<input type="text" class="form-control age-update" value="' + age + '">');
								//this.$('.number').html('<input type="text" class="form-control number-update" value="' + number + '">');
							},
							update: function(eve) {
								
								var updatebar = $(eve.currentTarget).data('updatebar');
								var string2 = new Array();
								
								string2[0] = "edit"+updatebar;
								string2[1] = "update"+updatebar;
								string2[2] = "cancel"+updatebar;
								string2[3] = "paymentId"+updatebar;
								string2[4] = "paymentType"+updatebar;
								string2[5] = "transactionType"+updatebar;
								string2[6] = "currency"+updatebar;
								string2[7] = "beneficiaryBank"+updatebar;
								string2[8] = "directionLabel"+updatebar;
								string2[9] = "conceptPayment"+updatebar;
								string2[10] = "referenceNumber"+updatebar;
								string2[11] = "typeOfOperation"+updatebar;
								string2[12] = "transactionAmount"+updatebar;
								
								string2[13] = "originatorDownstream"+updatebar;
								string2[14] = "targetUpstream"+updatebar;
								string2[15] = "topologyType"+updatebar;
								string2[16] = "transactionDate"+updatebar;
								string2[17] = "priority"+updatebar;
								
								
								
								console.log(string2[1]);
								this.$('#'+string2[0]).show();
								//$('.delete-blog').hide();
								
								this.$('#'+string2[1]).hide();
								this.$('#'+string2[2]).hide();
								//var sample=$('input[name=paymentId]').val();
								//console.log(sample);   $('#msg').html($('input:textbox').val())
								
								var directionLabel =$('#'+string2[8]).html($('#directionLabel').val());//$('#'+string2[3]).value();
								var conceptPayment =$('#'+string2[9]).html($('#conceptPayment').val() );
								var referenceNumber =$('#'+string2[10]).html($('#referenceNumber').val ()) ;
								var typeOfOperation =$('#'+string2[11]).html($('#typeOfOperation').val()) ;
								var transactionAmount =$('#'+string2[12]).html($('#transactionAmount').val()) ;
								
								var originatorDownstream =$('#'+string2[13]).html($('#originatorDownstream').val());//$('#'+string2[3]).value();
								var targetUpstream =$('#'+string2[14]).html($('#targetUpstream').val() );
								var topologyType =$('#'+string2[15]).html($('#topologyType').val ()) ;
								var transactionDate =$('#'+string2[16]).html($('#transactionDate').val()) ;
								var priority =$('#'+string2[17]).html($('#priority').val()) ;
								
								console.log(directionLabel);
								
								//this.tableviewdata.attributes.data[0].currency=
								// this.model.set('name', $('.name-update').val());
								// this.model.set('age', $('.age-update').val());
								// this.model.set('number', $('.number-update').val());
							// },
							// cancel: function() {
								// blogsView.render();
							// },
				},
				
				
				cancel: function(eve) {
					
					console.log("inside cancel");
								
								var cancelbar = $(eve.currentTarget).data('cancelbar');
								var string3 = new Array();
								
								string3[0] = "edit"+cancelbar;
								string3[1] = "update"+cancelbar;
								string3[2] = "cancel"+cancelbar;
								string3[3] = "paymentId"+cancelbar;
								string3[4] = "paymentType"+cancelbar;
								string3[5] = "transactionType"+cancelbar;
								string3[6] = "currency"+cancelbar;
								string3[7] = "beneficiaryBank"+cancelbar;
								string3[8] = "directionLabel"+cancelbar;
								string3[9] = "conceptPayment"+cancelbar;
								string3[10] = "referenceNumber"+cancelbar;
								string3[11] = "typeOfOperation"+cancelbar;
								string3[12] = "transactionAmount"+cancelbar;
								
								string3[13] = "originatorDownstream"+cancelbar;
								string3[14] = "targetUpstream"+cancelbar;
								string3[15] = "topologyType"+cancelbar;
								string3[16] = "transactionDate"+cancelbar;
								string3[17] = "priority"+cancelbar;
								
								
								console.log(string3[1]);
								this.$('#'+string3[0]).show();
								//$('.delete-blog').hide();
								
								this.$('#'+string3[1]).hide();
								this.$('#'+string3[2]).hide();
								//var sample=$('input[name=paymentId]').val();
								//console.log(sample);   $('#msg').html($('input:textbox').val())
								
								var directionLabel =$('#'+string3[8]).html($('#directionLabel').val());//$('#'+string2[3]).value();
								var conceptPayment =$('#'+string3[9]).html($('#conceptPayment').val() );
								var referenceNumber =$('#'+string3[10]).html($('#referenceNumber').val ()) ;
								var typeOfOperation =$('#'+string3[11]).html($('#typeOfOperation').val()) ;
								var transactionAmount =$('#'+string3[12]).html($('#transactionAmount').val()) ;
								
								
								var originatorDownstream =$('#'+string3[13]).html($('#originatorDownstream').val());//$('#'+string2[3]).value();
								var targetUpstream =$('#'+string3[14]).html($('#targetUpstream').val() );
								var topologyType =$('#'+string3[15]).html($('#topologyType').val ()) ;
								var transactionDate =$('#'+string3[16]).html($('#transactionDate').val()) ;
								var priority =$('#'+string3[17]).html($('#priority').val()) ;
								
							
								
								
				},
					
					
				
				
				
				el:$('#posthere'),
				template:Handlebars.compile(table),
				render:function(option){
					
				console.log("inside render");
				
					this.$el.html(this.template(
					{
						title:this.title,
						tableviewdata :this.tableviewdata,
						optionswork : this.optionswork,
						editString: this.editString,
						approveString: this.approveString
					}
					));
					
				}
			
			});                              
	return tableView;
});