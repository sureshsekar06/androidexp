define(['jquery','underscore','backbone','handlebar','collections/statusCollection','highcharts','highchart','text!templates/transaction/transaction.tpl'],
		function($,_,Backbone,Handlebars,CollectionData,Highcharts,Highchart,Transactiontpl){
			
			var myname;
			
			var TransactionView = Backbone.View.extend({
				
				initialize:function(option){
					this.Collobject2=option.Collobject1;
					
					console.log("heloooo");
					console.log(this.Collobject2);
					this.Collobject3=this.Collobject2.models;
					//console.log(this.Collobject3[0].attributes.data);
					statusNP = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "Payment"))
							statusNP += 1;
					}
					console.log(statusNP);
					
					statusNPE = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "PaymentEligible"))
							statusNPE += 1;
					}
					console.log(statusNPE);
					
					statusNPN = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "PaymentNotEligible"))
							statusNPN += 1;
					}
					console.log(statusNPN);
					
					statusAIS = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if(((this.Collobject3[0].attributes.data[i].status === "A")||(this.Collobject3[0].attributes.data[i].status === "I")||(this.Collobject3[0].attributes.data[i].status === "S"))&&(this.Collobject3[0].attributes.data[i].transactionType === "Payment"))
							statusAIS += 1;
					}
					console.log(statusAIS);
					
					
					statusNCE = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "CancelEligible"))
							statusNCE += 1;
					}
					console.log(statusNCE);
					
					statusNCN = 0;
					for(var i = 0 ; i <this.Collobject3[0].attributes.data.length; i++){
						if((this.Collobject3[0].attributes.data[i].status === "N")&&(this.Collobject3[0].attributes.data[i].transactionType === "CancelNotEligible"))
							statusNCN += 1;
					}
					console.log(statusNCN);
					
					this.statusNP = statusNP;
					this.statusNPE = statusNPE;
					this.statusNPN = statusNPN;
					this.statusAIS = statusAIS;
					this.statusNCE = statusNCE;
					this.statusNCN = statusNCN;
					
					
					this.render();
				},
				el:$('#posthere'),
				template:Handlebars.compile(Transactiontpl),
				render:function(option){
					console.log("inside render");
					this.$el.html(this.template({
						statusNP:this.statusNP,
						statusNPE:this.statusNPE,
						statusNPN:this.statusNPN,
						statusAIS:this.statusAIS,
						statusNCE:this.statusNCE,
						statusNCN:this.statusNCN
			
					}));                       
				}                              
			           
					   
			});                                
	return TransactionView;
}); 

