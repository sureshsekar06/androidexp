
$(document).ready(function(){
  $('.dropdown-submenu  a.test').on("click", function(e){
    e.stopPropagation();   
  });
});

$(".nav a").on("click", function(){
   $(".nav").find(".active").removeClass("active");
   $(this).parent().addClass("active");
});

$("ul.tabs > anchor").click(function() {
    // remove .active from all li descendants
    $("ul.tabs anchor").not(this).removeClass("active");

    $(this).addClass("active").find(".sub anchor").addClass("active");
});