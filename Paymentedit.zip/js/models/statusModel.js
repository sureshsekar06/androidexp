define([
  'underscore',
  'backbone'
 ], function(_, Backbone) {
	 
	 
	 var ModelObj = Backbone.Model.extend({
		 url : "testdata/sample/sample.json",
		
	 parse : function(response){
		
		  return response;
	  
	 }});
	 return ModelObj;
 });
 