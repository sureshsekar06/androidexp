define([
  'underscore',
  'backbone'
 ], function(_, Backbone) {
	 
	 
	 var tabledataModel = Backbone.Model.extend({
		 url : "testdata/sample/sample.json",
		 
	 parse : function(response){
		 
		 console.log("inside employee model");
		 
		  return response;
	  }
	 });
	 return tabledataModel;
 });
 
